<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ngô Thanh Thái - 1711062432</title>
    <link href="site.css" rel="stylesheet" />
</head>

<body>
    <div id="wrapper">
        <div class="container">
            <?php
            require_once("userclass.php");
            $thanhthai = new User('Ngo Thanh Thai', 'thanhthaiqngai3011@gmail.com');
            echo "<h2>---User Info---</h2>";

            echo "UserID: " . $thanhthai->GetUserID() . "</br>";
            echo "UserName: " . $thanhthai->GetUserEmail() . "</br>";
            echo "<hr>";
            $newuser = new User("Ngo Thu Uyen", "thuuyen@gmail.com");
            echo "<h2>---New User ---</h2>";
            echo "UserID: " . $newuser->GetUserID() . "</br>";
            echo "UserName: " . $newuser->GetUserEmail() . "</br>";
            //more OPP PHP
            echo "<hr>";
            include("employeeclass.php");
            $person_a = new Person("Nguyen Van A", 1234);
            echo "<h2>--More OPP PHP---</h2>";
            echo "Person Name: " . $person_a->GetName() . "</br>";
            echo "Person ID: " . $person_a->GetNationalID() . "</br>";
            echo "<hr>";
            echo "<h2>Employee</h2>";
            $employee_a = new Employee("Nguyen Van B", 5678, "Student");
            echo "Employee ID: " . $employee_a->GetEmployeeID() . "</br>";
            echo "Employee Name: " . $employee_a->GetName() . "</br>";

            echo "Employee Department: " . $employee_a->GetDepartment() . "</br>";
            echo "<hr>";
            echo "<h2>More Employee</h2>";
            $employee_b = new Employee("Nguyen Van C", 1203, "Teacher");
            echo "Employee ID: " . $employee_b->GetEmployeeID() . "</br>";
            echo "Employee Name: " . $employee_b->GetName() . "</br>";
            echo "Employee Department: " . $employee_b->GetDepartment() . "</br>";
            ?>
        </div>
    </div>
    <footer>
        &copy; 2020 Ngo Thanh Thai
    </footer>
</body>

</html>