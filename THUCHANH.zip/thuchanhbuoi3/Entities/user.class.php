<?php
    require_once("config/db.class.php");
    class User
    {
        public $userID;
        public $userName;
        public $email;
        public $pass;
        public function __construct($u_name, $u_email, $u_pass)
        {
            $this->userName = $u_name;
            $this->email = $u_email;
            $this->pass = $u_pass;
        }
        public function save()
        {
            $db = new Db();
            $sql = "INSERT INTO users(UserName, Email, Password) VALUES ('".mysqli_real_escape_string($db->connect(), $this->userName)."', '".mysqli_real_escape_string($db->connect(), $this->email)."', '".md5(mysqli_real_escape_string($db->connect(), $this->pass))."')";
            $result = $db->query_execute($sql);
            return $result;

        }
        public static function checkLogin($userName, $pass){
            $pass = md5($pass);
            $db = new Db();
            $sql = "SELECT * FROM users where UserName ='$userName' AND Password='$pass'";
            $result = $db->query_execute($sql);
            return $result;

        }
    }
?>