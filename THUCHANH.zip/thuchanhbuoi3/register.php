<?php
include_once('header.php');
?>
<?php
if (isset($_SESSION['user']) != "") {
    header("Location: index.php");
}
require_once('Entities/user.class.php');
if (isset($_POST['btn-signup'])) {
    $u_name = $_POST['txtname'];
    $u_email = $_POST['txtemail'];
    $u_pass = $_POST['txtpass'];
    $account = new User($u_name, $u_email, $u_pass);
    $result = $account->save();
    if (!$result) {
?>
        <script>
            alert('Có lỗi xảy ra, vui lòng kiểm tra dữ liệu!');
        </script>
<?php
    } else {
        $_SESSION['user'] = $u_name;
        header("Location: index.php");
    }
}
?>

<form action="" method="POST" style="width: 30%;">
    <div class="form-group row">
        <label for="txtname" class="col-lg-2 form-control-label">UserName
        </label>
        <div class="col-lg-10"><input type="text" class="form-control" name="txtname" placeholder="User Name"></div>
    </div>
    <div class="form-group row">
        <label for="txtemail" class="col-lg-2 form-control-label">Email</label>
        <div class="col-lg-10">
            <input type="text" name="txtemail" placeholder="Email" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        <label for="" class="col-lg-2 form-control-label">Password</label>
        <div class="col-lg-10">
            <input type="password" name="txtpass" placeholder="Password" class="form-control">
        </div>
    </div>
    <div class="form-group row">
        
        <div class="col-lg-offset-2 col-lg-10">
            <input type="submit" name="btn-signup" value="Sign Up">
        </div>
    </div>
</form>
<?php
    include_once("footer.php");
?>