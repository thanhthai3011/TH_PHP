<?php 
/* 
 * PayPal API configuration 
 * Remember to switch to your live API keys in production! 
 * See your keys here: https://developer.paypal.com/ 
 */ 
define('PAYPAL_API_CLIENT_ID', 'ARepqzIqkhRlP04n_WK-cG8aSE1ytD83_Jw4uRvKFwsLcsqnPWnNCv9doW2w3mFp32SnkjhwOIRoxfi9');  
define('PAYPAL_API_SECRET', 'EFOBkei06czCED5N-q6QyNCzCXV5ZqnL70MxjA8R9Ap0vve6oHQ6xQD85c8sEuhBoxyXOoHBH-8DavnS'); 
define('PAYPAL_SANDBOX', true); //set false for production 
  
// Database configuration  
define('DB_HOST', 'localhost');  
define('DB_USERNAME', 'root');  
define('DB_PASSWORD', '');  
define('DB_NAME', 'paypal');
?>