<!DOCTYPE html>
<html lang="vi">
<head>
	<meta charset="utf-8">
	<title>Xep loai ket qua tuyen sinh</title>
	<link href="/thuchanhbuoi1/site.css" rel="stylesheet"/>

</head>
<body>
	<div id="wrapper">
		<h2> Xep loai ket qua tuyen sinh</h2>
		<form action="#" method = "POST">
		<div class="row">
			<div class="lbltitle">
				<label>Diem mon toan</label>
			</div>
			<div class="lblinput">
				<input type="number"name ="Toan" value= "<?php echo isset($_POST["Toan"]) ? $_POST["Toan"] : "";?>"/>
			</div>	
		</div>
		<div class="row">
			<div class="lbltitle">
				<label>Diem mon ly</label>
			</div>
			<div class="lblinput">
				<input type="number"name ="Ly" value= "<?php echo isset($_POST["Ly"]) ? $_POST["Ly"] : "";?>"/>
			</div>	
		</div>
		<div class="row">
			<div class="lbltitle">
				<label>Diem mon hoa</label>
			</div>
			<div class="lblinput">
				<input type="number"name ="Hoa" value= "<?php echo isset($_POST["Hoa"]) ? $_POST["Hoa"] : "";?>"/>
			</div>	
		</div>
		<div class="row">
			<div class="lbltitle">
				<label>Chon khu vuc</label>
			</div>
			<div class="lblinput" >
				<select name="khuvuc" id="khuvuc">
					<option value="" selected> --Chon khu vuc--</option>
					<option value="1" <?php if(isset($_POST["khuvuc"]) && $_POST["khuvuc"]==1) echo "selected='selected'";?> > Khu vuc 1</option>
					<option value="2" <?php if(isset($_POST["khuvuc"]) && $_POST["khuvuc"]==2) echo "selected='selected'";?> > Khu vuc 2</option>
					<option value="3" <?php if(isset($_POST["khuvuc"]) && $_POST["khuvuc"]==3) echo "selected='selected'";?> > Khu vuc 3</option>
					<option value="4" <?php if(isset($_POST["khuvuc"]) && $_POST["khuvuc"]==4) echo "selected='selected'";?> > Khu vuc 4</option>
					<option value="5" <?php if(isset($_POST["khuvuc"]) && $_POST["khuvuc"]==5) echo "selected='selected'";?> > Khu vuc 5</option>
				</select>
			</div>	
		</div>
		<div class="row">
			<div class="submit">
				<input type="submit" name ="btnsubmit" value= "Xep loai"/>
			</div>	
		</div>
	</form>
	<div id="resulf">
		<h2>Ket qua xep loai</h2>
		<div class="row">
			<div class ="lbltitle">
				<label>Tong diem: </label>
			</div>
			<div class"lbloutput">
				<?php echo isset($_POST["btnsubmit"]) ? $_POST["Toan"] + $_POST["Ly"] + $_POST["Hoa"] : "";?>
			</div>
		</div>
		<div class="row">
			<div class ="lbltitle">
				<label>Xep loai: </label>
			</div>
			<div class"lbloutput">
				<?php
					if(isset($_POST["btnsubmit"])){

						$sum = $_POST["Toan"] + $_POST["Ly"] + $_POST["Hoa"] ;
						if($sum >=24)
							echo "Gioi";
						else if($sum >=21)
							echo "Kha";
						else if($sum >=15)
							echo "Trung binh";
						else {
							echo "Yeu";
						}
					}
				?>
				
			</div>
		</div>
		<div class="row">
			<div class ="lbltitle">
				<label>Diem uu tien: </label>
			</div>
			<div class"lbloutput">
				<?php
					if(isset($_POST["btnsubmit"])){

						$diemuutien = empty($_POST["khuvuc"]) ? 0:$_POST["khuvuc"];
				
						switch($diemuutien){
							case 0:
								echo "0";
								break;
							
							case 1:
								echo "1";
								break;
							case 2:
								echo "2";
								break;
							case 3:
								echo "3";
								break;
							case 4:
								echo "4";
								break;
							case 5:
								echo "5";
								break;
							default:	
								echo "";
							break;
						}
					}
				?>
				
			</div>
		</div>
	</div>
</div>
</body>

