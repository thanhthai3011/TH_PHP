<?php 
class Menu {
 
 private $__conn = null;
  
 // Kết nối
 function connect(){
     $this->__conn  = mysqli_connect('localhost', 'root', '', 'example');
 }
  
 // Đóng kết nối
 function close(){
     mysqli_close($this->__conn);
 }
  
 // Lấy danh sách Menu trả về một mảng
 function getList()
 {
     $this->connect();
     $result = array();
      
     $query = mysqli_query($this->__conn, 'select * from menu');
      
     if ($query){
         while ($row = mysqli_fetch_array($query, MYSQLI_ASSOC)){
             $result[] = $row;
         }
     }
     $this->close();
     return $result;
 }
}
?>