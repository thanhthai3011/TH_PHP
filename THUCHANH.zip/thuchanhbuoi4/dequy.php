<?php
function showMenuLi($menus, $id_parent = 0) 
{
    # BƯỚC 1: LỌC DANH SÁCH MENU VÀ CHỌN RA NHỮNG MENU CÓ ID_PARENT = $id_parent
     
    // Biến lưu menu lặp ở bước đệ quy này
    $menu_tmp = array();
 
    foreach ($menus as $key => $item) {
        // Nếu có parent_id bằng với parrent id hiện tại
        if ((int) $item['menu_parent_id'] == (int) $id_parent) {
            $menu_tmp[] = $item;
            // Sau khi thêm vào biên lưu trữ menu ở bước lặp
            // thì unset nó ra khỏi danh sách menu ở các bước tiếp theo
            unset($menus[$key]);
        }
    }
 
    # BƯỚC 2: lẶP MENU THEO DANH SÁCH MENU Ở BƯỚC 1
     
    // Điều kiện dừng của đệ quy là cho tới khi menu không còn nữa
    if ($menu_tmp) 
    {
        echo '<ul>';
        foreach ($menu_tmp as $item) 
        {
            echo '<li>';
            echo '<a href="' . $item['menu_link'] . '">' . $item['menu_title'] . '</a>';
            echo '<div>
                        <table border="0">
                            <tr>
                                <td>Title</td>
                                <td><input id="menu_title_' . $item['menu_id'] . '" value="' . $item['menu_title'] . '" /></td>
                            </tr>
                            <tr>
                                <td>Link</td>
                                <td><input id="menu_link_' . $item['menu_id'] . '" value="' . $item['menu_link'] . '" /></td>
                            </tr>
                            <tr>
                                <td>Parent</td>
                                <td>
                                    <select id="menu_parent_id_' . $item['menu_id'] . '">
                                    </select>
                                    <input type="button" data-id="' . $item['menu_id'] . '" class="button menu-save" value="Lưu" />
                                </td>
                            </tr>
                        </table>
                   </div>';
             
            // Gọi lại đệ quy
            // Truyền vào danh sách menu chưa lặp và id parent của menu hiện tại
            showMenuLi($menus, $item['menu_id']);
            echo '</li>';
        }
        echo '</ul>';
    }
}
?>
