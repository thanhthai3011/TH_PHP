<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ví dụ phân trang trong PHP và MySQL</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

</head>

<body>
    <?php
    $conn = mysqli_connect('localhost', 'root', '', 'example');
    $result = mysqli_query($conn, 'select count(ProductID) as total from product');
    $row = mysqli_fetch_assoc($result);
    $total_records = $row['total'];
    $current_page = isset($_GET['page']) ? $_GET['page'] : 1;
    $limit = 4;
    $total_page = ceil($total_records / $limit);
    if ($current_page > $total_page) {
        $current_page = $total_page;
    } else if ($current_page < 1) {
        $current_page = 1;
    }
    $start = ($current_page - 1) * $limit;
    $result = mysqli_query($conn, "SELECT * FROM product LIMIT $start, $limit");
    ?>
    <div class="header text-center">
    <h2>Ví dụ phân trang trong PHP và MySQL</h2>
    <br>
    </div>
    <div class="container">
    
        <div>
            <div class="row">

                <?php
                while ($row = mysqli_fetch_assoc($result)) { ?>
                    <div class="col-lg-6">
                        
                            <img src="<?php echo "uploads/" . $row["Picture"]; ?>" alt="Image" class="img-responsive" style="width: 50%;height: 50%">
                        <p class="text-danger">
                            <?php echo $row["ProductName"]; ?>
                        </p>
                        <p class="text-info">
                            <?php
                            echo $row["price"];
                            ?>
                        </p>
                        
                    </div>

                <?php } ?>
            </div>

        </div>
        <div class="pagination" style="float: right;">
            <?php
            if ($current_page > 1 && $total_page > 1) {
                echo '<a href="index.php?page=' . ($current_page - 1) . '">Prev</a> | ';
            }
            for ($i = 1; $i <= $total_page; $i++) {
                // Nếu là trang hiện tại thì hiển thị thẻ span
                // ngược lại hiển thị thẻ a
                if ($i == $current_page) {
                    echo '<span>' . $i . '</span> | ';
                } else {
                    echo '<a href="index.php?page=' . $i . '">' . $i . '</a> | ';
                }
            }
            if ($current_page < $total_page && $total_page > 1) {
                echo '<a href="index.php?page=' . ($current_page + 1) . '">Next</a> | ';
            }
            ?>
        </div>
        <hr>
        <footer>
        Create by Ngo Thanh Thai
        </footer>
    </div>

</body>

</html>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>